/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.user.bci;

/**
 *
 * @author Yves Matanga
 */
public enum Control2DPanelStateEnum {
    IDLE_STATE,TARGET_APPEAR_STATE,CURSOR_STATE,TARGET_REACHED_STATE,TARGET_NOT_REACHED_STATE,SCREEN_BLANK_STATE
}
