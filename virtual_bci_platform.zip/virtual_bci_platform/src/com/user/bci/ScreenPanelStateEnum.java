/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.user.bci;

/**
 *
 * @author Yves Matanga
 */
public enum ScreenPanelStateEnum {
    IDLE_STATE,CUE_STATE,BEEP_STATE,IMAGERY_STATE,BLANK_STATE
}
