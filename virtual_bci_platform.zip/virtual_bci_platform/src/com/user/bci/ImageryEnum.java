/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.user.bci;

/**
 *
 * @author Yves Matanga
 */
public enum ImageryEnum {
    LEFT_HAND,RIGHT_HAND,RIGHT_FOOT,LEFT_FOOT,REST
}
