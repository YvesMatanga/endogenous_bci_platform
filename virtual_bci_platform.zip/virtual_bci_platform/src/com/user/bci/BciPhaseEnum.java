/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.user.bci;

/**
 *
 * @author Yves Matanga
 */
public enum BciPhaseEnum {
    SCREENING_PHASE,HORIZONTAL_1D_PHASE,VERTICAL_1D_PHASE,CONTROL_2D_PHASE
}
